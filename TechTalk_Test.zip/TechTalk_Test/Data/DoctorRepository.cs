﻿using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using System.Collections.Generic;
using System.Data;
using TechTalk_Test.Model;
using tecktalk.dbengine;

namespace TechTalk_Test.Data
{
    public interface IDoctorRepository
    {
        DataTable loadSpecialty();
        DataTable GetTableData();
        DataTable fetchDoctorData(int Doctorid);

        Task<Resultargs> SaveDoctorDetails(DoctorModel doctorDetails);
        Resultargs DeleteDoctorDetails(int id);
        int GetDoctorCount();
    }
    public class DoctorRepository : IDoctorRepository
    {
        private readonly IConfiguration _configuration;

        private IMySqlServerHanlder objHandler;
        private string Query;
        public DoctorRepository(IMySqlServerHanlder sqlServerHanlder, IConfiguration configuration)
        {
            objHandler = sqlServerHanlder;
            _configuration = configuration;
        }
        public DataTable loadSpecialty()
        {
            Query = "SELECT SpecialtyId, SpecialtyName FROM Specialty";
            DataTable dtSpecialty = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtSpecialty;
        }

        public DataTable GetTableData()
        {
            Query = "SELECT DOCTORID, NAME, SpecialtyId, CONTACTNUMBER, EMAIL, QUALIFICATIONS, AVAILABILITY  FROM DOCTOR";
            DataTable dtDoctors = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtDoctors;
        }

        public DataTable fetchDoctorData(int Doctorid)
        {
            Query = "SELECT DOCTORID, NAME, SpecialtyId, CONTACTNUMBER, EMAIL, QUALIFICATIONS, AVAILABILITY  FROM DOCTOR WHERE DOCTORID = @Doctorid";
            MySqlParameter[] parameters = { new MySqlParameter("@Doctorid", Doctorid) };
            DataTable dtDoctor = objHandler.ExecuteTable(Query, CommandType.Text, parameters);
            return dtDoctor;
        }

        public async Task<Resultargs> SaveDoctorDetails(DoctorModel doctorDetails)
        {
            Resultargs resultargs = new Resultargs();
            string query;

           
            if (doctorDetails == null)
            {
                throw new ArgumentNullException(nameof(doctorDetails), "Doctor details cannot be null");
            }

            try
            {
               
                if (doctorDetails.DoctorId == 0) 
                {
                    query = @"INSERT INTO doctor (Name, SpecialtyId, ContactNumber, Email, Qualifications, Availability) 
                      VALUES (@Name, @SpecialtyId, @ContactNumber, @Email, @Qualifications, @Availability)";
                }
                else 
                {
                    query = @"UPDATE doctor 
                      SET Name = @Name, SpecialtyId = @SpecialtyId, ContactNumber = @ContactNumber, 
                          Email = @Email, Qualifications = @Qualifications, Availability = @Availability 
                      WHERE DoctorId = @DoctorId";
                }

                
                var parameters = new MySqlParameter[]
                {
            new MySqlParameter("@Name", doctorDetails.Name),
            new MySqlParameter("@SpecialtyId", doctorDetails.SpecialtyId),
            new MySqlParameter("@ContactNumber", doctorDetails.ContactNumber),
            new MySqlParameter("@Email", doctorDetails.Email),
            new MySqlParameter("@Qualifications", doctorDetails.Qualifications),
            new MySqlParameter("@Availability", doctorDetails.Availability)
                };

                
                if (doctorDetails.DoctorId != 0)
                {
                    Array.Resize(ref parameters, parameters.Length + 1);
                    parameters[parameters.Length - 1] = new MySqlParameter("@DoctorId", doctorDetails.DoctorId);
                }

               
                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);

               
                if (result > 0)
                {
                    resultargs.StatusMessage = "Doctor details saved successfully";
                    resultargs.ResultData = result;
                    resultargs.StatusCode = 200; 
                    resultargs.IsSuccess = true;
                }
                else
                {
                    resultargs.StatusMessage = "Failed to save doctor details";
                    resultargs.ResultData = result;
                    resultargs.StatusCode = 400; 
                    resultargs.IsSuccess = false; 
                }
            }
            catch (Exception ex)
            {
              
                resultargs.StatusMessage = $"An error occurred: {ex.Message}";
                resultargs.StatusCode = 500; 
                resultargs.IsSuccess = false;
            }

            return resultargs;
        }


        public Resultargs DeleteDoctorDetails(int id)
        {
            Resultargs resultargs = new Resultargs();
            string query = "DELETE FROM Doctor WHERE DOCTORID = @id";

            try
            {
                MySqlParameter[] parameters = { new MySqlParameter("@id", id) };
                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);
                resultargs.ResultData = result > 0;
                resultargs.StatusMessage = result > 0 ? "Deleted Successfully" : "Delete Failed";
            }
            catch (Exception ex)
            {
                resultargs.StatusMessage = "Error: " + ex.Message;
            }

            return resultargs;
        }
        public int GetDoctorCount()
        {
            int count = 0;

            try
            {
                string query = "SELECT COUNT(*) FROM doctor";
                count = Convert.ToInt32(objHandler.ExecuteScalar(query, CommandType.Text));
            }
            catch (Exception ex)
            {
              
                Console.WriteLine($"Error retrieving doctor count: {ex.Message}");
            }

            return count;
        }
    }
}