﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Security.Claims;
using System.Text;
using TechTalk_Test.Model;
using tecktalk.dbengine;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;

namespace TechTalk_Test.Data
{
    public interface ILoginRepository
    {
        DoctorModel ValidateUser(string username, string password);
        DataTable GetConfirmedAppointmentsByDoctor(string doctorName);
        string GenerateJwtToken(string username); // Added method to generate JWT
    }

    public class LoginRepository : ILoginRepository
    {
        private readonly IMySqlServerHanlder objHandler;
        private const string SecretKey = "YourVerySecureAndLongSecretKey123!"; // Use a secure key
        private readonly IConfiguration _configuration;

        public LoginRepository(IMySqlServerHanlder sqlServerHanlder, IConfiguration configuration)
        {
            objHandler = sqlServerHanlder;
            _configuration = configuration;
        }

        public DoctorModel ValidateUser(string username, string password)
        {
            string query = "SELECT DoctorId, Name FROM login WHERE Name = @Username AND Password = @Password"; // Ensure password is hashed

            MySqlParameter[] parameters =
            {
                new MySqlParameter("@Username", username),
                new MySqlParameter("@Password", password) // Ensure to compare hashed password
            };

            try
            {
                using (var reader = objHandler.ExecuteReader(query, CommandType.Text, parameters))
                {
                    if (reader != null && reader.Read()) // Check if reader is not null and can read
                    {
                        return new DoctorModel
                        {
                            DoctorId = reader.GetInt32("DoctorId"),
                            Name = reader["Name"].ToString()
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception (use your logging framework here)
                Console.WriteLine($"Error during user validation: {ex.Message}");
            }

            return null; // Return null if the user is not found
        }

        public DataTable GetConfirmedAppointmentsByDoctor(string doctorName)
        {
            string query = @"SELECT AppointmentId, UserName, Email, AppointmentDateTime, ProblemType, IsConfirmed, CancellationReason 
                             FROM Appointments 
                             WHERE DoctorName = @DoctorName AND IsConfirmed = true";

            MySqlParameter[] parameters = { new MySqlParameter("@DoctorName", doctorName) };

            try
            {
                // Execute the query synchronously and return the DataTable
                return objHandler.ExecuteTable(query, CommandType.Text, parameters);
            }
            catch (Exception ex)
            {
                // Log the exception (use your logging framework here) --
                Console.WriteLine($"Error retrieving confirmed appointments: {ex.Message}");
                return null; // Return null or an empty DataTable based on your application's needs
            }
        }


        public string GenerateJwtToken(string username)
        {
            var claims = new[]
            {
            new Claim(JwtRegisteredClaimNames.Sub, username),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"])); // Access from config
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}

