﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using TechTalk_Test.Model;
using tecktalk.dbengine;

namespace TechTalk_Test.Data
{
    public interface IAppointmentRepository
    {
        DataTable LoadDoctors();
        DataTable LoadAppointments();
        DataTable FetchAppointmentData(int appointmentId);
        Task<Resultargs> SaveAppointmentDetails(AppointmentModel appointmentDetails);
        Resultargs DeleteAppointmentDetails(int id);
        Resultargs ConfirmAppointment(int id);
        Resultargs CancelAppointment(int id, string cancellationReason);
        DataTable LoadAppointmentsByEmail(string email);
        int GetAppointmentCount();
        DataTable GetConfirmedAppointmentsByDoctor(string doctorName);
    }

    public class AppointmentRepository : IAppointmentRepository
    {
        private readonly IMySqlServerHanlder objHandler;
        private readonly IEmailRepository emailRepository;
        private string Query;

        public AppointmentRepository(IMySqlServerHanlder sqlServerHandler, IEmailRepository emailRepository)
        {
            objHandler = sqlServerHandler;
            this.emailRepository = emailRepository;

        }

        public DataTable LoadDoctors()
        {
            Query = "SELECT DoctorId, Name FROM Doctor"; 
            DataTable dtDoctors = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtDoctors;
        }

        public DataTable LoadAppointments()
        {
            Query = @"SELECT AppointmentId, DoctorName, UserName, Email, AppointmentDateTime, ProblemType, IsConfirmed 
                      FROM Appointments";
            DataTable dtAppointments = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtAppointments;
        }

        public DataTable FetchAppointmentData(int appointmentId)
        {
            Query = @"SELECT AppointmentId, DoctorName, UserName, Email, AppointmentDateTime, ProblemType, IsConfirmed ,CancellationReason
                      FROM Appointments WHERE AppointmentId = @AppointmentId";
            MySqlParameter[] parameters = { new MySqlParameter("@AppointmentId", appointmentId) };
            DataTable dtAppointment = objHandler.ExecuteTable(Query, CommandType.Text, parameters);
            return dtAppointment;
        }

        public async Task<Resultargs> SaveAppointmentDetails(AppointmentModel appointmentDetails)
        {
            Resultargs resultargs = new Resultargs();
            string query;

            if (appointmentDetails == null)
            {
                throw new ArgumentNullException(nameof(appointmentDetails), "Appointment details cannot be null");
            }

            try
            {
                query = @"INSERT INTO Appointments (DoctorName, UserName, Email, AppointmentDateTime, ProblemType, IsConfirmed, CancellationReason) 
                  VALUES (@DoctorName, @UserName, @Email, @AppointmentDateTime, @ProblemType, @IsConfirmed, @CancellationReason)";

                var parameters = new MySqlParameter[]
                {
            new MySqlParameter("@DoctorName", appointmentDetails.DoctorName),
            new MySqlParameter("@UserName", appointmentDetails.UserName),
            new MySqlParameter("@Email", appointmentDetails.Email),
            new MySqlParameter("@AppointmentDateTime", appointmentDetails.AppointmentDateTime),
            new MySqlParameter("@ProblemType", appointmentDetails.ProblemType),
            new MySqlParameter("@IsConfirmed", appointmentDetails.IsConfirmed),
        
                };

                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);

                if (result > 0)
                {
                    resultargs.StatusMessage = "Appointment saved successfully";
                    resultargs.ResultData = result;
                    resultargs.StatusCode = 201; 
                    resultargs.IsSuccess = true;
                 
                    resultargs.AppointmentModel = appointmentDetails; 
                }
                else
                {
                    resultargs.StatusMessage = "Failed to save appointment details";
                    resultargs.ResultData = result;
                    resultargs.StatusCode = 400;
                    resultargs.IsSuccess = false;
                }
            }
            catch (Exception ex)
            {
                resultargs.StatusMessage = $"An error occurred: {ex.Message}";
                resultargs.StatusCode = 500;
                resultargs.IsSuccess = false;
            }

            return resultargs;
        }


        public Resultargs DeleteAppointmentDetails(int id)
        {
            Resultargs resultargs = new Resultargs();
            string query = "SELECT COUNT(*) FROM Appointments WHERE AppointmentId = @id";

            try
            {
              
                MySqlParameter[] checkParameters = { new MySqlParameter("@id", id) };
                int count = Convert.ToInt32(objHandler.ExecuteScalar(query, CommandType.Text, checkParameters));

                if (count == 0)
                {
                    resultargs.IsSuccess = false;
                    resultargs.StatusMessage = "Appointment not found.";
                    return resultargs;
                }

               
                query = "DELETE FROM Appointments WHERE AppointmentId = @id";
                MySqlParameter[] deleteParameters = { new MySqlParameter("@id", id) };
                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, deleteParameters);

                resultargs.IsSuccess = result > 0;
                resultargs.StatusMessage = result > 0 ? "Deleted Successfully" : "Delete Failed";
            }
            catch (Exception ex)
            {
                resultargs.StatusMessage = "Error: " + ex.Message;
            }

            return resultargs;
        }


        public Resultargs ConfirmAppointment(int id)
        {
            Resultargs resultargs = new Resultargs();
            string updateQuery = "UPDATE Appointments SET IsConfirmed = 1 WHERE AppointmentId = @id";
            string selectQuery = "SELECT Email FROM Appointments WHERE AppointmentId = @id";

            try
            {
                MySqlParameter[] parameters = { new MySqlParameter("@id", id) };
                int affectedRows = objHandler.ExecuteNonQuery(updateQuery, CommandType.Text, parameters);

                if (affectedRows > 0)
                {
                    var email = objHandler.ExecuteScalar(selectQuery, CommandType.Text, parameters);

                    resultargs.IsSuccess = true;
                    resultargs.StatusMessage = "Appointment confirmed successfully.";
                    resultargs.AppointmentModel = new AppointmentModel
                    {
                        Email = email?.ToString()
                    };
                }
                else
                {
                    resultargs.IsSuccess = false;
                    resultargs.StatusMessage = "No appointment found with the provided ID, or it is already confirmed.";
                }
            }
            catch (MySqlException sqlEx)
            {
                resultargs.IsSuccess = false;
                resultargs.StatusMessage = "Database error: " + sqlEx.Message;
            }
            catch (Exception ex)
            {
                resultargs.IsSuccess = false;
                resultargs.StatusMessage = "Error: " + ex.Message;
            }

            return resultargs;
        }


        public Resultargs CancelAppointment(int id, string cancellationReason)
        {
            Resultargs result = new Resultargs();
            string updateQuery = "UPDATE Appointments SET IsConfirmed = @isConfirmed, CancellationReason = @cancellationReason WHERE AppointmentId = @id";
            string selectQuery = "SELECT Email FROM Appointments WHERE AppointmentId = @id";

            try
            {
                MySqlParameter[] parameters = { new MySqlParameter("@id", id) };
                var email = objHandler.ExecuteScalar(selectQuery, CommandType.Text, parameters);

                if (email != null)
                {
                 
                    MySqlParameter[] updateParameters = {
                new MySqlParameter("@isConfirmed", false),
                new MySqlParameter("@cancellationReason", cancellationReason),
                new MySqlParameter("@id", id)
            };

                    int rowsAffected = objHandler.ExecuteNonQuery(updateQuery, CommandType.Text, updateParameters);
                    if (rowsAffected > 0)
                    {
                        result.IsSuccess = true;
                        result.AppointmentModel = new AppointmentModel { Email = email.ToString() }; // Return the email if needed
                        result.StatusMessage = "Appointment canceled successfully.";
                    }
                    else
                    {
                        result.IsSuccess = false;
                        result.StatusMessage = "Failed to cancel appointment.";
                    }
                }
                else
                {
                    result.IsSuccess = false;
                    result.StatusMessage = "Appointment not found.";
                }
            }
            catch (Exception ex)
            {
                
                Console.WriteLine($"Error in CancelAppointment repository: {ex.Message}");
                result.IsSuccess = false;
                result.StatusMessage = "Error: " + ex.Message;
            }

            return result;
        }
        public DataTable GetConfirmedAppointmentsByDoctor(string doctorName)
        {
            string query = @"SELECT AppointmentId, UserName, Email, AppointmentDateTime, ProblemType, IsConfirmed, CancellationReason 
                     FROM Appointments 
                     WHERE DoctorName = @DoctorName AND IsConfirmed = true"; 

            MySqlParameter[] parameters = { new MySqlParameter("@DoctorName", doctorName) };

        
            DataTable dtAppointments = objHandler.ExecuteTable(query, CommandType.Text, parameters);
            return dtAppointments;
        }

        public DataTable LoadAppointmentsByEmail(string email)
        {
            string query = @"SELECT AppointmentId, DoctorName, UserName, Email, AppointmentDateTime, ProblemType, IsConfirmed ,CancellationReason
                     FROM Appointments WHERE Email = @Email";

            MySqlParameter[] parameters = { new MySqlParameter("@Email", email) };

          
            DataTable dtAppointments = objHandler.ExecuteTable(query, CommandType.Text, parameters);
            return dtAppointments;
        }
        public int GetAppointmentCount()
        {
            int count = 0;

            try
            {
                string query = "SELECT COUNT(*) FROM appointments"; 
                count = Convert.ToInt32(objHandler.ExecuteScalar(query, CommandType.Text));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving appointment count: {ex.Message}");
            }

            return count;
        }
    }
}
