﻿using System.Threading.Tasks;

public interface IEmailRepository
{
    Task SendEmailAsync(string email, string subject, string message);
}

public class EmailRepository : IEmailRepository
{
    private readonly EmailService _emailService;

    public EmailRepository(EmailService emailService)
    {
        _emailService = emailService;
    }

    public async Task SendEmailAsync(string email, string subject, string message)
    {
        await _emailService.SendEmailAsync(email, subject, message);
    }
}
