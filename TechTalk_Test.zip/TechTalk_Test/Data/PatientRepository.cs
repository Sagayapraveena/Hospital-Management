﻿
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using TechTalk_Test.Model;
using tecktalk.dbengine;

namespace TechTalk_Test.Data
{
    public interface IPatientRepository
    {
        DataTable LoadDoctors(); // Method to load doctor names for the dropdown
        Task<Resultargs> SavePatientDetails(PatientModel patientDetails);
        DataTable GetPatientData(); // Method to fetch patient data
        DataTable FetchPatientData(int patientId); // Method to fetch specific patient data
        Resultargs DeletePatientDetails(int id); // Method to delete patient data
      
        string GetDoctorNameByPatientName(string patientName);
        int GetPatientCount();
    }

    public class PatientRepository : IPatientRepository
    {
        private readonly IConfiguration _configuration;
        private IMySqlServerHanlder objHandler;
        private string Query;

        public PatientRepository(IMySqlServerHanlder sqlServerHanlder, IConfiguration configuration)
        {
            objHandler = sqlServerHanlder;
            _configuration = configuration;
        }

        public DataTable LoadDoctors()
        {
            Query = "SELECT DoctorId, Name FROM Doctor"; // Fetching doctor details
            DataTable dtDoctors = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtDoctors;
        }

        public async Task<Resultargs> SavePatientDetails(PatientModel patientDetails)
        {
            Resultargs resultargs = new Resultargs();
            string query;

            // Check if the patientDetails object is null
            if (patientDetails == null)
            {
                throw new ArgumentNullException(nameof(patientDetails), "Patient details cannot be null");
            }

            try
            {
                // Determine if it's an insert or update
                if (patientDetails.PatientId == 0) // New patient
                {
                    query = @"INSERT INTO Patient (PatientName, HandledByDoctor, DOB, Gender, Weight, BloodGroup, Symptoms, ContactNumber) 
                      VALUES (@PatientName, @HandledByDoctor, @DOB, @Gender, @Weight, @BloodGroup, @Symptoms, @ContactNumber)";
                }
                else // Existing patient
                {
                    query = @"UPDATE Patient 
                      SET PatientName = @PatientName, HandledByDoctor = @HandledByDoctor, DOB = @DOB, 
                          Gender = @Gender, Weight = @Weight, BloodGroup = @BloodGroup, Symptoms = @Symptoms, 
                          ContactNumber = @ContactNumber 
                      WHERE PatientId = @PatientId";
                }

                // Define parameters for the query
                var parameters = new MySqlParameter[]
                {
            new MySqlParameter("@PatientName", patientDetails.PatientName),
            new MySqlParameter("@HandledByDoctor", patientDetails.HandledByDoctor),
            new MySqlParameter("@DOB", patientDetails.DOB),
            new MySqlParameter("@Gender", patientDetails.Gender),
            new MySqlParameter("@Weight", patientDetails.Weight),
            new MySqlParameter("@BloodGroup", patientDetails.BloodGroup),
            new MySqlParameter("@Symptoms", patientDetails.Symptoms),
            new MySqlParameter("@ContactNumber", patientDetails.ContactNumber)
                };

                // Add PatientId only for updates
                if (patientDetails.PatientId != 0)
                {
                    Array.Resize(ref parameters, parameters.Length + 1);
                    parameters[parameters.Length - 1] = new MySqlParameter("@PatientId", patientDetails.PatientId);
                }

                // Execute the query synchronously
                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);

                // Check if the query was successful
                if (result > 0)
                {
                    resultargs.StatusMessage = "Patient details saved successfully";
                    resultargs.ResultData = result;
                    resultargs.StatusCode = 200; // Success
                    resultargs.IsSuccess = true; // Set isSuccess to true
                }
                else
                {
                    resultargs.StatusMessage = "Failed to save patient details";
                    resultargs.ResultData = result;
                    resultargs.StatusCode = 400; // Bad Request
                    resultargs.IsSuccess = false; // Set isSuccess to false
                }
            }
            catch (Exception ex)
            {
                // Log the exception and return an error response
                resultargs.StatusMessage = $"An error occurred: {ex.Message}";
                resultargs.StatusCode = 500; // Internal Server Error
                resultargs.IsSuccess = false; // Set isSuccess to false
            }

            return resultargs;
        }

        public Resultargs DeletePatientDetails(int id)
        {
            Resultargs resultargs = new Resultargs();
            string query = "DELETE FROM Patient WHERE PatientId = @id"; // Ensure the column name is correct

            try
            {
                // Create parameters for the query
                MySqlParameter[] parameters = { new MySqlParameter("@id", id) };

                // Log the query and parameters for debugging
                Console.WriteLine($"Executing query: {query}, with parameter id: {id}");

                // Execute the delete command and store the result
                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);

                // Determine the success of the operation
                if (result > 0)
                {
                    resultargs.StatusMessage = "Deleted Successfully";
                    resultargs.ResultData = true; // Indicate that deletion was successful
                    resultargs.IsSuccess = true; // Track success state
                }
                else
                {
                    resultargs.StatusMessage = "Delete Failed"; // No rows affected
                    resultargs.ResultData = false; // Indicate failure
                    resultargs.IsSuccess = false; // Track failure state
                }
            }
            catch (MySqlException sqlEx)
            {
                // Log specific SQL exceptions for easier debugging
                resultargs.StatusMessage = "Database error: " + sqlEx.Message;
                resultargs.IsSuccess = false; // Set IsSuccess to false
            }
            catch (Exception ex)
            {
                // Log general exceptions
                resultargs.StatusMessage = "Error: " + ex.Message;
                resultargs.IsSuccess = false; // Set IsSuccess to false
            }

            return resultargs;
        }



        public int GetPatientIdByName(string patientName)
        {
            string query = "SELECT PatientId FROM Patients WHERE PatientName = @PatientName";
            MySqlParameter[] parameters = { new MySqlParameter("@PatientName", patientName) };

            object result = objHandler.ExecuteScalar(query, CommandType.Text, parameters);
            return result != null ? Convert.ToInt32(result) : 0;
        }


        public DataTable GetPatientData()
        {
            Query = "SELECT PatientId, PatientName, HandledByDoctor, DOB, Gender, Weight, BloodGroup, Symptoms, ContactNumber FROM Patient";
            DataTable dtPatients = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtPatients;
        }

        public DataTable FetchPatientData(int patientId)
        {
            Query = "SELECT PatientId, PatientName, HandledByDoctor, DOB, Gender, Weight, BloodGroup, Symptoms, ContactNumber FROM Patient WHERE PatientId = @PatientId";
            MySqlParameter[] parameters = { new MySqlParameter("@PatientId", patientId) };
            DataTable dtPatient = objHandler.ExecuteTable(Query, CommandType.Text, parameters);
            return dtPatient;
        }

        public string GetDoctorNameByPatientName(string patientName)
        {
            string doctorName = string.Empty;

            // SQL query to retrieve the doctor's name handled by the patient
            string query = "SELECT d.Name FROM Patient p JOIN Doctor d ON p.HandledByDoctor = d.DoctorId WHERE p.PatientName = @PatientName";

            // Create parameters for the SQL command
            var parameters = new MySqlParameter[]
            {
        new MySqlParameter("@PatientName", patientName)
            };

            // Execute the query and get the result
            object result = objHandler.ExecuteScalar(query, CommandType.Text, parameters);

            // Check if a result was returned and set the doctor name
            if (result != null)
            {
                doctorName = result.ToString();
            }

            return doctorName;
        }

        public int GetPatientCount()
        {
            int count = 0;

            try
            {
                string query = "SELECT COUNT(*) FROM patient"; // Adjust table name as needed
                count = Convert.ToInt32(objHandler.ExecuteScalar(query, CommandType.Text));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving patient count: {ex.Message}");
            }

            return count;
        }
    }
}
