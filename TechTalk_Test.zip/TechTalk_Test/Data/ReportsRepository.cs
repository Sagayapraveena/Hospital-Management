﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using TechTalk_Test.Model;
using tecktalk.dbengine;

namespace TechTalk_Test.Data
{
    public interface IReportRepository
    {
        Resultargs SaveReportDetails(ReportModel reportDetails);
        DataTable GetReports();
        Task<DataTable> FetchReportDataAsync(int patientId);
        Resultargs DeleteReport(int reportId);
        string GetDoctorNameByPatientId(int patientId);
        int GetReportCount();
        DataTable FetchMedicalReportData(int reportId);
    }

    public class ReportRepository : IReportRepository
    {
        private readonly IConfiguration _configuration;
        private IMySqlServerHanlder objHandler;
        private string Query;

        public ReportRepository(IMySqlServerHanlder sqlServerHanlder, IConfiguration configuration)
        {
            objHandler = sqlServerHanlder;
            _configuration = configuration;
        }
        public Resultargs SaveReportDetails(ReportModel reportDetails)
        {
            Resultargs resultargs = new Resultargs();
            string query;

            if (reportDetails == null)
            {
                throw new ArgumentNullException(nameof(reportDetails), "Report details cannot be null");
            }

            try
            {
               
                if (reportDetails.ReportId == 0)
                {
                    query = @"INSERT INTO MedicalReports (PatientId, PatientName, DoctorName, Diagnosis, Treatment, ReportDate) 
                      VALUES (@PatientId, @PatientName, @DoctorName, @Diagnosis, @Treatment, @ReportDate)";
                }
                else 
                {
                    query = @"UPDATE MedicalReports 
                      SET PatientId = @PatientId, PatientName = @PatientName, DoctorName = @DoctorName, 
                          Diagnosis = @Diagnosis, Treatment = @Treatment, ReportDate = @ReportDate 
                      WHERE ReportId = @ReportId";
                }

             
                var parameters = new MySqlParameter[]
                {
            new MySqlParameter("@PatientId", reportDetails.PatientId),
            new MySqlParameter("@PatientName", reportDetails.PatientName),
            new MySqlParameter("@DoctorName", reportDetails.DoctorName),
            new MySqlParameter("@Diagnosis", reportDetails.Diagnosis),
            new MySqlParameter("@Treatment", reportDetails.Treatment),
            new MySqlParameter("@ReportDate", reportDetails.ReportDate)
                };

                // 
                if (reportDetails.ReportId != 0)
                {
                    Array.Resize(ref parameters, parameters.Length + 1);
                    parameters[parameters.Length - 1] = new MySqlParameter("@ReportId", reportDetails.ReportId);
                }

                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);

              
                if (result > 0)
                {
                    resultargs.StatusMessage = "Report details saved successfully";
                    resultargs.StatusCode = 200; 
                    resultargs.IsSuccess = true;
                }
                else
                {
                    resultargs.StatusMessage = "Failed to save report details";
                    resultargs.StatusCode = 400; 
                    resultargs.IsSuccess = false;
                }
            }
            catch (Exception ex)
            {
                resultargs.StatusMessage = $"An error occurred: {ex.Message}";
                resultargs.StatusCode = 500;
                resultargs.IsSuccess = false;
            }

            return resultargs;
        }

        public DataTable GetReports()
        {
            Query = "SELECT ReportId, PatientId, PatientName, DoctorName, Diagnosis, Treatment, ReportDate FROM MedicalReports";
            DataTable dtReports = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtReports;
        }

        public async Task<DataTable> FetchReportDataAsync(int patientId)
        {
            string query = "SELECT ReportId, PatientId, PatientName, DoctorName, Diagnosis, Treatment, ReportDate " +
                           "FROM MedicalReports WHERE PatientId = @PatientId";

            MySqlParameter[] parameters = { new MySqlParameter("@PatientId", patientId) };

          
            DataTable dtReports = await Task.Run(() => objHandler.ExecuteTable(query, CommandType.Text, parameters));

            return dtReports; 
        }


        public Resultargs DeleteReport(int reportId)
        {
            Resultargs resultargs = new Resultargs();
            string query = "DELETE FROM MedicalReports WHERE ReportId = @reportId";

            try
            {
                MySqlParameter[] parameters = { new MySqlParameter("@reportId", reportId) };
                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);

                resultargs.ResultData = result > 0;
                resultargs.StatusMessage = result > 0 ? "Deleted Successfully" : "Delete Failed";
                resultargs.IsSuccess = result > 0;
            }
            catch (Exception ex)
            {
                resultargs.StatusMessage = "Error: " + ex.Message;
            }

            return resultargs;
        }
        public string GetDoctorNameByPatientId(int patientId)
        {
            string doctorName = string.Empty;
            string query = "SELECT HandledByDoctor FROM Patients WHERE PatientId = @PatientId";
            var parameters = new MySqlParameter[] { new MySqlParameter("@PatientId", patientId) };

            object result = objHandler.ExecuteScalar(query, CommandType.Text, parameters);

            if (result != null)
            {
                doctorName = result.ToString();
            }

            return doctorName; 
        }
        public DataTable FetchMedicalReportData(int reportId)
        {
            string query = "SELECT ReportId, PatientId, PatientName, DoctorName, Diagnosis, Treatment, ReportDate FROM MedicalReports WHERE ReportId = @ReportId";
            MySqlParameter[] parameters = { new MySqlParameter("@ReportId", reportId) };

            DataTable dtMedicalReport = objHandler.ExecuteTable(query, CommandType.Text, parameters);
            return dtMedicalReport;
        }

        public int GetReportCount()
        {
            int count = 0;

            try
            {
                string query = "SELECT COUNT(*) FROM medicalreports"; 
                count = Convert.ToInt32(objHandler.ExecuteScalar(query, CommandType.Text));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving report count: {ex.Message}");
            }

            return count;
        }
    }

}
