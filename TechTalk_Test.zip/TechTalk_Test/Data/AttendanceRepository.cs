﻿using HospitalApi.Model;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Data;
using TechTalk_Test.Model;
using tecktalk.dbengine;

namespace TechTalk_Test.Data
{
    public interface IAttendanceRepository
    {
        Task<Resultargs> SaveAttendanceDetails(AttendanceModel attendanceDetails);
        Resultargs DeleteAttendanceDetails(int id);
        DataTable GetAttendanceData();
        DataTable GetAttendanceByDoctorId(int doctorId);
        DataTable FetchAttendanceData(int id);
        int GetAttendanceCount();
    }
    public class AttendanceRepository : IAttendanceRepository
    {
        private readonly IConfiguration _configuration;
        private IMySqlServerHanlder objHandler;
        private string Query;

        public AttendanceRepository(IMySqlServerHanlder sqlServerHanlder, IConfiguration configuration)
        {
            objHandler = sqlServerHanlder;
            _configuration = configuration;
        }

        public async Task<Resultargs> SaveAttendanceDetails(AttendanceModel attendanceDetails)
        {
            Resultargs resultargs = new Resultargs();
            string query;

            // Check if the attendanceDetails object is null
            if (attendanceDetails == null)
            {
                throw new ArgumentNullException(nameof(attendanceDetails), "Attendance details cannot be null");
            }

            try
            {
                // Determine if it's an insert or update
                if (attendanceDetails.AttendanceId == 0) // New attendance record
                {
                    query = @"INSERT INTO Attendance (DoctorName, Date, AttendanceStatus) 
                              VALUES (@DoctorName, @Date, @AttendanceStatus)";
                }
                else // Existing attendance record
                {
                    query = @"UPDATE Attendance 
                              SET DoctorName = @DoctorName, Date = @Date, AttendanceStatus = @AttendanceStatus 
                              WHERE AttendanceId = @AttendanceId";
                }

                // Define parameters for the query
                var parameters = new MySqlParameter[]
                {
                    new MySqlParameter("@DoctorName", attendanceDetails.DoctorName),
                    new MySqlParameter("@Date", attendanceDetails.Date),
                    new MySqlParameter("@AttendanceStatus", attendanceDetails.AttendanceStatus)
                };

                // Add AttendanceId only for updates
                if (attendanceDetails.AttendanceId != 0)
                {
                    Array.Resize(ref parameters, parameters.Length + 1);
                    parameters[parameters.Length - 1] = new MySqlParameter("@AttendanceId", attendanceDetails.AttendanceId);
                }

                // Execute the query synchronously
                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);

                // Check if the query was successful
                if (result > 0)
                {
                    resultargs.StatusMessage = "Attendance details saved successfully";
                    resultargs.ResultData = result;
                    resultargs.StatusCode = 200; // Success
                    resultargs.IsSuccess = true; // Set isSuccess to true
                }
                else
                {
                    resultargs.StatusMessage = "Failed to save attendance details";
                    resultargs.ResultData = result;
                    resultargs.StatusCode = 400; // Bad Request
                    resultargs.IsSuccess = false; // Set isSuccess to false
                }
            }
            catch (Exception ex)
            {
                // Log the exception and return an error response
                resultargs.StatusMessage = $"An error occurred: {ex.Message}";
                resultargs.StatusCode = 500; // Internal Server Error
                resultargs.IsSuccess = false; // Set isSuccess to false
            }

            return resultargs;
        }

        public Resultargs DeleteAttendanceDetails(int id)
        {
            Resultargs resultargs = new Resultargs();
            string query = "DELETE FROM Attendance WHERE AttendanceId = @id";

            try
            {
                MySqlParameter[] parameters = { new MySqlParameter("@id", id) };
                int result = objHandler.ExecuteNonQuery(query, CommandType.Text, parameters);
                resultargs.ResultData = result > 0;
                resultargs.StatusMessage = result > 0 ? "Deleted Successfully" : "Delete Failed";
            }
            catch (Exception ex)
            {
                resultargs.StatusMessage = "Error: " + ex.Message;
            }

            return resultargs;
        }

        public DataTable GetAttendanceData()
        {
            Query = "SELECT AttendanceId, DoctorName, Date, AttendanceStatus FROM Attendance";
            DataTable dtAttendance = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtAttendance;
        }
        public DataTable FetchAttendanceData(int id)
        {
            Query = "SELECT AttendanceId, DoctorName, Date, AttendanceStatus FROM Attendance";
            DataTable dtAttendance = objHandler.ExecuteTable(Query, CommandType.Text);
            return dtAttendance;
        }

        public DataTable GetAttendanceByDoctorId(int doctorId)
        {
            Query = "SELECT AttendanceId, DoctorName, Date, AttendanceStatus FROM Attendance WHERE DoctorId = @DoctorId";
            MySqlParameter[] parameters = { new MySqlParameter("@DoctorId", doctorId) };
            DataTable dtAttendance = objHandler.ExecuteTable(Query, CommandType.Text, parameters);
            return dtAttendance;
        }

        public int GetAttendanceCount()
        {
            int count = 0;

            try
            {
                string query = "SELECT COUNT(*) FROM Attendance";
                count = Convert.ToInt32(objHandler.ExecuteScalar(query, CommandType.Text));
            }
            catch (Exception ex)
            {
                // Log the error (you can replace this with your logging framework)
                Console.WriteLine($"Error retrieving attendance count: {ex.Message}");
            }

            return count;
        }

       
    }
}