﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TechTalk_Test.Data;

namespace TechTalk_Test.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly IEmailRepository _emailRepository;

        public EmailController(IEmailRepository emailRepository)
        {
            _emailRepository = emailRepository;
        }

        [HttpPost("send-confirmation-email")]
        public async Task<IActionResult> SendConfirmationEmail(string email, string userName)
        {
            string subject = "Appointment Confirmation";
            string message = $"Hello {userName},\n\nYour appointment has been confirmed successfully.\n\nThank you!";

            try
            {
                await _emailRepository.SendEmailAsync(email, subject, message);
                return Ok(new { StatusMessage = "Confirmation email sent successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { StatusMessage = "Failed to send confirmation email: " + ex.Message });
            }
        }

        [HttpPost("send-cancellation-email")]
        public IActionResult SendCancellationEmail(string email, string userName)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return BadRequest(new { statusMessage = "Email address cannot be null or empty." });
            }

            try
            {
                // Assuming you have an email service that sends the email
                _emailRepository.SendEmailAsync(email, "Appointment Canceled", $"Dear {userName}, your appointment has been canceled.");
                return Ok(new { statusMessage = "Cancellation email sent successfully." });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to send cancellation email: {ex.Message}");
                return StatusCode(500, new { statusMessage = $"Failed to send cancellation email: {ex.Message}" });
            }
        }

    }
}
