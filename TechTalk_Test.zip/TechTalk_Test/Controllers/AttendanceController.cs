﻿using HospitalApi.Model;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Threading.Tasks;
using TechTalk_Test.Data;
using TechTalk_Test.Model;

namespace TechTalk_Test.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class AttendanceController : ControllerBase
    {
        private readonly IAttendanceRepository _schoolRepository;

        public AttendanceController(IAttendanceRepository schoolRepository)
        {
            _schoolRepository = schoolRepository;
        }

        // GET: Retrieve all attendance records
        [HttpGet]
        public IActionResult GetAttendanceData()
        {
            Resultargs resultargs = new Resultargs();
            DataTable table = _schoolRepository.GetAttendanceData();

            if (table != null && table.Rows.Count > 0)
            {
                List<Dictionary<string, object>> responseData = new List<Dictionary<string, object>>();

                foreach (DataRow row in table.Rows)
                {
                    Dictionary<string, object> childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in table.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    responseData.Add(childRow);
                }
                resultargs.ResultData = responseData;
                resultargs.StatusCode = 200;
            }
            else
            {
                resultargs.StatusCode = 200;
                resultargs.StatusMessage = "No Attendance Record Available";
            }
            return Ok(resultargs);
        }

        // POST: Save or Update Attendance Details
        [HttpPost]
        public async Task<IActionResult> SaveAttendance([FromBody] AttendanceModel attendance)
        {
            Resultargs resultargs = await _schoolRepository.SaveAttendanceDetails(attendance);
            return Ok(resultargs);
        }

        // DELETE: Delete Attendance by ID
        [HttpDelete("{id}")]
        public IActionResult DeleteAttendance(int id)
        {
            Resultargs resultargs = _schoolRepository.DeleteAttendanceDetails(id);
            return Ok(resultargs);
        }

        // GET: Get Attendance Count
        [HttpGet("count")]
        public IActionResult GetAttendanceCount()
        {
            try
            {
                int count = _schoolRepository.GetAttendanceCount();
                return Ok(new { count });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
        [HttpGet("{id}")]
        public IActionResult GetAttendance(int id)
        {
            var attendanceData = _schoolRepository.FetchAttendanceData(id);

            if (attendanceData.Rows.Count == 0)
            {
                return NotFound($"Attendance record with ID {id} not found.");
            }

            // Convert DataTable to a more usable format
            var responseData = new Dictionary<string, object>();
            foreach (DataColumn col in attendanceData.Columns)
            {
                responseData.Add(col.ColumnName, attendanceData.Rows[0][col]);
            }

            return Ok(responseData);
        }


    }
}
