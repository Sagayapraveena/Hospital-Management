﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using TechTalk_Test.Data;
using TechTalk_Test.Model;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;
using MySql.Data.MySqlClient;

namespace TechTalk_Test.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class HomeController : ControllerBase
    {
        private readonly IDoctorRepository _doctorRepository;
        private readonly IConfiguration _configuration;

        public HomeController(IDoctorRepository doctorRepository, IConfiguration configuration)
        {
            _doctorRepository = doctorRepository;
            _configuration = configuration;
        }

        // GET: Load Specialties
        [HttpGet("api/specialties")]
        public IActionResult GetSpecialties()
        {
            try
            {
                DataTable table = _doctorRepository.loadSpecialty();
                if (table != null && table.Rows.Count > 0)
                {
                    var specialties = new List<Specialty>();
                    foreach (DataRow row in table.Rows)
                    {
                        specialties.Add(new Specialty
                        {
                            SpecialtyId = Convert.ToInt32(row["SpecialtyId"]),
                            SpecialtyName = row["SpecialtyName"].ToString()
                        });
                    }
                    return Ok(new { StatusCode = 200, ResultData = specialties });
                }
                else
                {
                    return Ok(new { StatusCode = 200, ResultData = new List<Specialty>() }); // Return empty list
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { StatusCode = 500, Message = $"Error: {ex.Message}" });
            }
        }



        // GET
        [HttpGet]
        public IActionResult GetTableData()
        {
            Resultargs resultargs = new Resultargs();
            DataTable table = _doctorRepository.GetTableData();

            if (table != null && table.Rows.Count > 0)
            {
                List<Dictionary<string, object>> responseData = new List<Dictionary<string, object>>();

                foreach (DataRow row in table.Rows)
                {
                    Dictionary<string, object> childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in table.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    responseData.Add(childRow);
                }
                resultargs.ResultData = responseData;
                resultargs.StatusCode = 200;
            }
            else
            {
                resultargs.StatusCode = 200;
                resultargs.StatusMessage = "No Record Available";
            }
            return Ok(resultargs);
        }

     
        // POST: Save or Update Doctor Details
        [HttpPost]
        public async Task<IActionResult> SaveDoctor([FromForm] DoctorModel doctorDetails)
        {
           
            Resultargs resultargs = new Resultargs();

           
            resultargs = await _doctorRepository.SaveDoctorDetails(doctorDetails);

         
            return Ok(resultargs);
        }

        // DELETE: Delete a Doctor by ID
        [HttpDelete("{id}")]
        public IActionResult DeleteDoctor(int id)
        {
            Resultargs resultargs = _doctorRepository.DeleteDoctorDetails(id);
            if (resultargs.ResultData != null && (bool)resultargs.ResultData)
            {
                resultargs.StatusCode = 200;
                resultargs.StatusMessage = "Doctor deleted successfully";
            }
            else
            {
                resultargs.StatusCode = 500;
                resultargs.StatusMessage = "Error deleting doctor";
            }
            return Ok(resultargs);
        }
     
        [HttpGet("count")]
        public IActionResult GetDoctorsCount()
        {
            try
            {
                int count = _doctorRepository.GetDoctorCount();
                return Ok(new { count });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

    }

}

