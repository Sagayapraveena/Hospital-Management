﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Threading.Tasks;
using TechTalk_Test.Data;
using TechTalk_Test.Model;

namespace TechTalk_Test.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReportsController : ControllerBase
    {
        private readonly IReportRepository _reportRepository;
        private readonly IPatientRepository _patientRepository;

        public ReportsController(IReportRepository reportRepository, IPatientRepository patientRepository)
        {
            _reportRepository = reportRepository;
            _patientRepository = patientRepository;
        }

        [HttpPost]
        public IActionResult SaveReport([FromForm] ReportModel reportDetails)
        {
         
            if (reportDetails == null)
            {
                return BadRequest("Report details cannot be null");
            }

           
            var result = _reportRepository.SaveReportDetails(reportDetails);

          
            if (result.IsSuccess)
            {
              
                return CreatedAtAction(nameof(GetAllReports), new
                {
                    id = reportDetails.ReportId, 
                    reportId = result.ReportId 
                }, result); 
            }

           
            return BadRequest(result.StatusMessage);
        }



   
        [HttpGet]
        public IActionResult GetAllReports()
        {
            Resultargs resultargs = new Resultargs();
            DataTable table = _reportRepository.GetReports();

            if (table != null && table.Rows.Count > 0)
            {
                List<Dictionary<string, object>> responseData = new List<Dictionary<string, object>>();

                foreach (DataRow row in table.Rows)
                {
                    Dictionary<string, object> childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in table.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    responseData.Add(childRow);
                }
                resultargs.ResultData = responseData;
                resultargs.StatusCode = 200;
            }
            else
            {
                resultargs.StatusCode = 200;
                resultargs.StatusMessage = "No Record Available";
            }
            return Ok(resultargs);
        }



   
        [HttpDelete("{reportId}")]
        public IActionResult DeleteReport(int reportId)
        {
            var result = _reportRepository.DeleteReport(reportId);
            if (result.IsSuccess)
            {
                return Ok(result.StatusMessage);
            }
            return BadRequest(result.StatusMessage);
        }
        [HttpGet("reports/count")]
        public IActionResult GetReportsCount()
        {
            try
            {
                int count = _reportRepository.GetReportCount();
                return Ok(new { count });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
        [HttpGet("{id}")]
        public IActionResult GetReport(int id)
        {
            var reportData = _reportRepository.FetchMedicalReportData(id);
            if (reportData.Rows.Count == 0)
            {
                return NotFound($"Report with ID {id} not found.");
            }

            // Convert DataTable to a more usable format
            var responseData = new Dictionary<string, object>();
            foreach (DataColumn col in reportData.Columns)
            {
                responseData.Add(col.ColumnName, reportData.Rows[0][col]);
            }

            return Ok(responseData);
        }


    }
}