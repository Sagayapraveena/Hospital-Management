﻿using HospitalApi.Model;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data;
using System.Security.Claims;
using System.Text;
using TechTalk_Test.Data;
using TechTalk_Test.Model;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.Extensions.Configuration;

namespace TechTalk_Test.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginRepository _loginRepository;
        private readonly IConfiguration _configuration;

        public LoginController(ILoginRepository loginRepository, IConfiguration configuration)
        {
            _loginRepository = loginRepository;
            _configuration = configuration;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginModel loginRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var doctor = _loginRepository.ValidateUser(loginRequest.Username, loginRequest.Password);
            if (doctor == null)
            {
                return Unauthorized(new { message = "Invalid username or password." });
            }

            // Generate JWT token
            var token = GenerateJwtToken(doctor.Name);

            // Fetch confirmed appointments
            var confirmedAppointments = _loginRepository.GetConfirmedAppointmentsByDoctor(doctor.Name);
            List<Dictionary<string, object>> responseData = new List<Dictionary<string, object>>();

            if (confirmedAppointments != null && confirmedAppointments.Rows.Count > 0)
            {
                foreach (DataRow row in confirmedAppointments.Rows)
                {
                    Dictionary<string, object> childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in confirmedAppointments.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    responseData.Add(childRow);
                }
            }

            return Ok(new
            {
                message = "Login successful.",
                doctorId = doctor.DoctorId,
                doctorName = doctor.Name,
                token, // Include the token in the response
                confirmedAppointments = responseData
            });
        }

        private string GenerateJwtToken(string username)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, username),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            // Ensure this is a secure key (32 bytes for HS256)
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}
