﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TechTalk_Test.Model;
using TechTalk_Test.Data;
using System.Data;
using System.Collections.Generic;

namespace TechTalk_Test.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly IAppointmentRepository _appointmentRepository;
        private readonly EmailService _emailService;

        public AppointmentController(IAppointmentRepository appointmentRepository, EmailService emailService)
        {
            _appointmentRepository = appointmentRepository;
            _emailService = emailService;
        }

        // GET: api/appointment
        [HttpGet]
        public IActionResult GetAllAppointments()
        {
            Resultargs resultargs = new Resultargs();
            DataTable table = _appointmentRepository.LoadAppointments();

            if (table != null && table.Rows.Count > 0)
            {
                List<Dictionary<string, object>> responseData = new List<Dictionary<string, object>>();

                foreach (DataRow row in table.Rows)
                {
                    Dictionary<string, object> childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in table.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    responseData.Add(childRow);
                }
                resultargs.ResultData = responseData;
                resultargs.StatusCode = 200;
            }
            else
            {
                resultargs.StatusCode = 200;
                resultargs.StatusMessage = "No Record Available";
            }
            return Ok(resultargs);
        }

        // GET: api/appointment/{id}
        //[HttpGet("{id}")]
        //public IActionResult GetAppointment(int id)
        //{
        //    var appointmentData = _appointmentRepository.FetchAppointmentData(id);
        //    if (appointmentData.Rows.Count == 0)
        //    {
        //        return NotFound($"Appointment with ID {id} not found.");
        //    }

        //    var appointment = new Dictionary<string, object>();
        //    foreach (DataColumn col in appointmentData.Columns)
        //    {
        //        appointment.Add(col.ColumnName, appointmentData.Rows[0][col]);
        //    }

        //    return Ok(appointment);
        //}

        // POST: api/appointment
        [HttpPost]
        public async Task<IActionResult> SaveAppointment([FromForm] AppointmentModel appointmentDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = await _appointmentRepository.SaveAppointmentDetails(appointmentDetails);
            if (result.IsSuccess)
            {
                return CreatedAtAction(nameof(GetAllAppointments), new { id = appointmentDetails.AppointmentId }, result);
            }
            return BadRequest(result.StatusMessage);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteAppointment(int id)
        {
            try
            {
               
                Resultargs result = _appointmentRepository.DeleteAppointmentDetails(id);

               
                if (result.IsSuccess)
                {
                    return Ok(new { message = result.StatusMessage }); // Return success message
                }
                else
                {
                    return NotFound(new { message = result.StatusMessage }); // Return 404 if not found
                }
            }
            catch (Exception ex)
            {
              
                return StatusCode(500, new { message = "An error occurred while deleting the appointment.", error = ex.Message });
            }
        }


        [HttpGet("doctors")]
        public IActionResult LoadDoctors()
        {
           
            var dataTable = _appointmentRepository.LoadDoctors();

          
            if (dataTable == null || dataTable.Rows.Count == 0)
            {
                return NotFound("No doctors found.");
            }

       
            var doctors = new List<DoctorModel>();
            foreach (DataRow row in dataTable.Rows)
            {
                var doctor = new DoctorModel
                {
                    DoctorId = (int)row["DoctorId"],
                    Name = (string)row["Name"]
                };
                doctors.Add(doctor);
            }

           
            return Ok(doctors);
        }
        // PUT: api/appointment/confirm/{id}
        //[HttpPut("confirm/{id}")]
        //public IActionResult ConfirmAppointment(int id)
        //{
        //    // Call the repository method to confirm the appointment
        //    Resultargs result = _appointmentRepository.ConfirmAppointment(id);

        //    // Check if the appointment was confirmed successfully
        //    if (result.IsSuccess)
        //    {
        //        // Return a success response with a message
        //        return Ok(new
        //        {
        //            statusCode = 200,
        //            message = result.StatusMessage
        //        });
        //    }
        //    else
        //    {
        //        // Log the error message for debugging purposes (optional)
        //        // _logger.LogError($"Error confirming appointment {id}: {result.StatusMessage}");

        //        // Return a 500 status code with the error message
        //        return StatusCode(500, new
        //        {
        //            statusCode = 500,
        //            message = result.StatusMessage
        //        });
        //    }
        //}
        //[HttpDelete("cancel/{id}")]
        //public IActionResult CancelAppointment(int id)
        //{
        //    try
        //    {
        //        // Call the repository method to cancel the appointment
        //        Resultargs result = _appointmentRepository.CancelAppointment(id); // Corrected method call

        //        if (result.IsSuccess)
        //        {
        //            // Return a successful response with the message
        //            return Ok(new { message = result.StatusMessage });
        //        }
        //        else
        //        {
        //            // If the operation was not successful, return a BadRequest or a relevant status code
        //            return BadRequest(new { message = result.StatusMessage });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        // Log the exception (you can use a logging framework or simply log to console)
        //        Console.WriteLine($"Error canceling appointment with ID {id}: {ex.Message}");

        //        // Return a generic error response
        //        return StatusCode(500, new { message = "An error occurred while canceling the appointment." });
        //    }
        //}

        [HttpPut("confirm/{id}")]
        public IActionResult ConfirmAppointment(int id)
        {
            try
            {
            
                Resultargs result = _appointmentRepository.ConfirmAppointment(id);

                if (result.IsSuccess)
                {
                    try
                    {
                        // Send confirmation email
                        _emailService.SendEmailAsync(result.AppointmentModel.Email,
                            "Appointment Confirmed",
                            $"Your appointment with ID {id} has been confirmed.");
                    }
                    catch (Exception emailEx)
                    {
                        // Log error if email sending fails
                        Console.WriteLine($"Error sending confirmation email: {emailEx.Message}");
                    }

                    return Ok(new { message = result.StatusMessage });
                }
                else
                {
                    return BadRequest(new { message = result.StatusMessage });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error confirming appointment: {ex.Message}");
                return StatusCode(500, new { message = "An error occurred while confirming the appointment." });
            }
        }

        [HttpPost("cancel")]
        public IActionResult CancelAppointment([FromBody] CancelAppointmentRequest request)
        {
            // Validate request
            if (request.AppointmentId <= 0)
            {
                return BadRequest(new { message = "Invalid appointment ID." });
            }

            if (string.IsNullOrWhiteSpace(request.CancellationReason))
            {
                return BadRequest(new { message = "Cancellation reason is required." });
            }

            try
            {
               
                Resultargs result = _appointmentRepository.CancelAppointment(request.AppointmentId, request.CancellationReason);

                if (result.IsSuccess)
                {
                   
                    return Ok(new { message = result.StatusMessage });
                }
                else
                {
                    
                    return BadRequest(new { message = result.StatusMessage });
                }
            }
            catch (Exception ex)
            {
               
                Console.WriteLine($"An error occurred while canceling the appointment: {ex.Message}");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }



        // GET: api/appointment/user?email={email}
        [HttpGet("user")]
        public IActionResult GetAppointmentsByEmail(string email)
        {
         
            if (string.IsNullOrEmpty(email))
            {
                return BadRequest("Email is required.");
            }

            // Fetch appointments for the given email
            DataTable appointmentData = _appointmentRepository.LoadAppointmentsByEmail(email);

            if (appointmentData != null && appointmentData.Rows.Count > 0)
            {
                List<Dictionary<string, object>> responseData = new List<Dictionary<string, object>>();

                foreach (DataRow row in appointmentData.Rows)
                {
                    Dictionary<string, object> childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in appointmentData.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    responseData.Add(childRow);
                }

                return Ok(new Resultargs
                {
                    ResultData = responseData,
                    StatusCode = 200
                });
            }
            else
            {
                return NotFound("No appointments found for this email.");
            }
        }
        [HttpGet("appointments/count")]
        public IActionResult GetAppointmentsCount()
        {
            try
            {
                int count = _appointmentRepository.GetAppointmentCount();
                return Ok(new { count });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
        // GET: api/appointment/confirmed?doctorName={doctorName}
        [HttpGet("confirmed")]
        public IActionResult GetConfirmedAppointmentsByDoctor(string doctorName)
        {
            // Validate the input
            if (string.IsNullOrEmpty(doctorName))
            {
                return BadRequest("Doctor name is required.");
            }

            // Fetch confirmed appointments for the specified doctor
            DataTable confirmedAppointments = _appointmentRepository.GetConfirmedAppointmentsByDoctor(doctorName);

            if (confirmedAppointments != null && confirmedAppointments.Rows.Count > 0)
            {
                List<Dictionary<string, object>> responseData = new List<Dictionary<string, object>>();

                foreach (DataRow row in confirmedAppointments.Rows)
                {
                    Dictionary<string, object> childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in confirmedAppointments.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    responseData.Add(childRow);
                }

                return Ok(new Resultargs
                {
                    ResultData = responseData,
                    StatusCode = 200
                });
            }
            else
            {
                return NotFound("No confirmed appointments found for this doctor.");
            }
        }

    }
}

    


