﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TechTalk_Test.Model;
using TechTalk_Test.Data;
using System.Data;

namespace TechTalk_Test.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IPatientRepository _patientRepository;

        public PatientController(IPatientRepository patientRepository)
        {
            _patientRepository = patientRepository;
        }

        //// GET: api/patient
        //[HttpGet]
        //public IActionResult GetAllPatients()
        //{
        //    var patients = _patientRepository.GetPatientData();
        //    if (patients.Rows.Count == 0)
        //    {
        //        return NotFound("No patients found.");
        //    }
        //    return Ok(patients);
        //}

        // GET: api/patient/{id}
        //[HttpGet("{id}")]
        //public IActionResult GetPatient(int id)
        //{
        //    var patientData = _patientRepository.FetchPatientData(id);
        //    if (patientData.Rows.Count == 0)
        //    {
        //        return NotFound($"Patient with ID {id} not found.");
        //    }
        //    return Ok(patientData);
        //}
        // GET: Retrieve all doctor records
        [HttpGet]
        public IActionResult GetAllPatients()
        {
            Resultargs resultargs = new Resultargs();
            DataTable table = _patientRepository.GetPatientData();

            if (table != null && table.Rows.Count > 0)
            {
                List<Dictionary<string, object>> responseData = new List<Dictionary<string, object>>();

                foreach (DataRow row in table.Rows)
                {
                    Dictionary<string, object> childRow = new Dictionary<string, object>();
                    foreach (DataColumn col in table.Columns)
                    {
                        childRow.Add(col.ColumnName, row[col]);
                    }
                    responseData.Add(childRow);
                }
                resultargs.ResultData = responseData;
                resultargs.StatusCode = 200;
            }
            else
            {
                resultargs.StatusCode = 200;
                resultargs.StatusMessage = "No Record Available";
            }
            return Ok(resultargs);
        }

        // POST: api/patient
        [HttpPost]
        public async Task<IActionResult> SavePatient([FromForm] PatientModel patientDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = await _patientRepository.SavePatientDetails(patientDetails);
            if (result.IsSuccess)
            {
                return CreatedAtAction(nameof(GetAllPatients), new { id = patientDetails.PatientId }, result);
            }
            return BadRequest(result.StatusMessage);
        }

        // DELETE api/patient/{id}
        // DELETE: api/Patient/{id}
        [HttpDelete("{id}")]
        public IActionResult DeletePatient(int id)
        {
            // Call the DeletePatientDetails method in the repository
            Resultargs result = _patientRepository.DeletePatientDetails(id);

            if (result.IsSuccess)
            {
                return Ok(new { message = result.StatusMessage });
            }
            else
            {
                return StatusCode(500, new { message = result.StatusMessage }); // Consider using a more specific status code
            }
        }



        // GET: api/patient/doctors
        [HttpGet("doctors")]
        public IActionResult LoadDoctors()
        {
            // Fetch the doctor data using the repository
            var dataTable = _patientRepository.LoadDoctors();

            // Check if the data table is null or empty
            if (dataTable == null || dataTable.Rows.Count == 0)
            {
                return NotFound("No doctors found.");
            }

            // Create a list of DoctorModel DTOs
            var doctors = new List<DoctorModel>();
            foreach (DataRow row in dataTable.Rows)
            {
                var doctor = new DoctorModel
                {
                    DoctorId = (int)row["DoctorId"],
                    Name = (string)row["Name"]
                };
                doctors.Add(doctor);
            }

            // Return the list of DTOs
            return Ok(doctors);
        }
        [HttpGet("doctor-by-patient/{patientName}")]
        public IActionResult GetDoctorByPatientName(string patientName)
        {
            // Validate input
            if (string.IsNullOrWhiteSpace(patientName))
            {
                return BadRequest("Patient name cannot be empty.");
            }

            // Retrieve the doctor's name using the repository
            var doctorName = _patientRepository.GetDoctorNameByPatientName(patientName);

            // Check if a doctor name was found
            if (string.IsNullOrEmpty(doctorName))
            {
                return NotFound($"No doctor found for patient '{patientName}'.");
            }

            // Return the doctor name in the response
            return Ok(new { DoctorName = doctorName });
        }

        [HttpGet("patients/count")]
        public IActionResult GetPatientsCount()
        {
            try
            {
                int count = _patientRepository.GetPatientCount();
                return Ok(new { count });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
        [HttpGet("{id}")]
        public IActionResult GetPatient(int id)
        {
            var patientData = _patientRepository.FetchPatientData(id);
            if (patientData.Rows.Count == 0)
            {
                return NotFound($"Patient with ID {id} not found.");
            }

            // Convert DataTable to a more usable format
            var responseData = new Dictionary<string, object>();
            foreach (DataColumn col in patientData.Columns)
            {
                responseData.Add(col.ColumnName, patientData.Rows[0][col]);
            }

            return Ok(responseData);
        }

    }
}
