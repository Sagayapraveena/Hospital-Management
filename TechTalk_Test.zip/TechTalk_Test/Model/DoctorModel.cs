﻿using System.ComponentModel.DataAnnotations;

namespace TechTalk_Test.Model
{
    public class Specialty
    {
        public int SpecialtyId { get; set; }
        public string SpecialtyName { get; set; }
    }


    public class Resultargs
    {
        public object ResultData { get; set; }
        public string StatusMessage { get; set; }
        public int StatusCode { get; set; }

        public int ReportId { get; set; }
        public bool IsSuccess { get; set; }
          
            public AppointmentModel AppointmentModel { get; set; } // Include the Appointment object
           
        public string ErrorMessage { get; set; }

    }


    public class DoctorModel
    {
        public int DoctorId { get; set; } // Auto-increment primary key

        [Required]
        [StringLength(255)]
        public string Name { get; set; } // Not null
        [Required]
        public int? SpecialtyId { get; set; } // Foreign key, nullable
        [Required]
        [StringLength(15)]
        public string ContactNumber { get; set; } // Nullable
        [Required]
        [EmailAddress]
        [StringLength(255)]
        public string Email { get; set; } // Nullable
        [Required]
        public string Qualifications { get; set; } // Text field, no specific length
        [Required]
        [StringLength(100)]
        public string Availability { get; set; } // Nullable

        
    }



}
