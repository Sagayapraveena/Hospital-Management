﻿namespace TechTalk_Test.Model
{
    public class ReportModel
    {
        public int ReportId { get; set; }
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public string DoctorName { get; set; }
        public string Diagnosis { get; set; }
        public string Treatment { get; set; }
        public DateTime ReportDate { get; set; }
     
    }
}
