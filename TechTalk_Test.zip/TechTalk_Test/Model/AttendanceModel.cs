﻿using System.ComponentModel.DataAnnotations;

namespace HospitalApi.Model
{
    public class AttendanceModel
    {



       
            public int AttendanceId { get; set; }
            public string DoctorName { get; set; }
            public DateTime Date { get; set; }
            public string AttendanceStatus { get; set; }
        }
    
}
