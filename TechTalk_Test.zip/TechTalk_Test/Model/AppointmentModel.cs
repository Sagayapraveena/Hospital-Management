﻿using System.ComponentModel.DataAnnotations;

namespace TechTalk_Test.Model
{
    public class AppointmentModel
    {
        public int AppointmentId { get; set; }
        public string DoctorName { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public DateTime AppointmentDateTime { get; set; }
        public string ProblemType { get; set; }
        public bool IsConfirmed { get; set; } = false; // Default value, admin can change this later
     
    }

    public class CancelAppointmentRequest
    {
        public int AppointmentId { get; set; }
        public string CancellationReason { get; set; }
    }


}
