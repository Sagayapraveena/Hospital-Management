﻿namespace TechTalk_Test.Model
{
    public class PatientModel
    {
       
            public int PatientId { get; set; }
            public string PatientName { get; set; }
            public int HandledByDoctor { get; set; } // Foreign Key referencing the Doctor table
            public DateTime DOB { get; set; }
            public string Gender { get; set; }
            public decimal Weight { get; set; }
            public string BloodGroup { get; set; }
            public string Symptoms { get; set; }
            public string ContactNumber { get; set; }
        }

    }

