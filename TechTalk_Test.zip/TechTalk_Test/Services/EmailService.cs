﻿using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

public class EmailService
{
    private readonly IConfiguration _configuration;

    public EmailService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task SendEmailAsync(string email, string subject, string message)
    {
        var smtpSettings = _configuration.GetSection("SmtpSettings");

        using (var client = new SmtpClient(smtpSettings["Server"], int.Parse(smtpSettings["Port"])))
        {
            client.Credentials = new NetworkCredential(smtpSettings["Username"], smtpSettings["Password"]);
            client.EnableSsl = true;

            var mailMessage = new MailMessage
            {
                From = new MailAddress(smtpSettings["Username"]),
                Subject = subject,
                Body = message,
                IsBodyHtml = true,
            };
            mailMessage.To.Add(email);

            try
            {
                await client.SendMailAsync(mailMessage);
            }
            catch (SmtpException smtpEx)
            {
                // Log SMTP-related exceptions (you may want to use a logging framework here)
                Console.WriteLine($"SMTP Error: {smtpEx.Message}");
                throw; // Rethrow or handle it as necessary
            }
            catch (Exception ex)
            {
                // Log any other exceptions (you may want to use a logging framework here)
                Console.WriteLine($"Error sending email: {ex.Message}");
                throw; // Rethrow or handle it as necessary
            }
        }
    }
}
